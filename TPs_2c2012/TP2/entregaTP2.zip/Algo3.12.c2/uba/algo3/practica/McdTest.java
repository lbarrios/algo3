package uba.algo3.practica;

import static org.junit.Assert.assertEquals;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.StringTokenizer;
import org.junit.Test;


public class McdTest {

   static Mcd eu = new Mcd();
   

   @Test
   public void testMcdAFromAFile() throws Exception {
      BufferedReader reader  = new BufferedReader( new FileReader( "mcd.in" ) );
      String linea;
      
      while ( (linea = reader.readLine()) != null ) {
         assertEquals( "linea: " + linea, Integer.parseInt( linea ), runOn( reader.readLine() ) );
      }
   }
   
   @Test
   public void testMcdAFormStrings() {
      assertEquals( 1, runOn( "10, 23" ) );
      assertEquals( 2, runOn( "10, 24" ) );
      assertEquals( 3, runOn( "237, 42" ) );
      assertEquals( 1, runOn( "23, 10" ) );
      assertEquals( 8, runOn( "128, 8" ) );
   }
   
   private int runOn( String string ) {
      StringTokenizer st = new StringTokenizer( string, "," );
      return eu.mcdA( Integer.parseInt( st.nextToken().trim() ), Integer.parseInt( st.nextToken().trim() ) );
   }



   @Test
   public void testMcdA() {
      assertEquals( 1, eu.mcdA( 10, 23 ) );
      assertEquals( 2, eu.mcdA( 10, 24 ) );
      assertEquals( 3, eu.mcdA( 237, 42 ) );
      assertEquals( 1, eu.mcdA( 23, 10 ) );
      assertEquals( 8, eu.mcdA( 128, 8 ) );
      
   }

   @Test
   public void testMcdB() {
      assertEquals( 1, eu.mcdB( 10, 23 ) );
      assertEquals( 2, eu.mcdB( 10, 24 ) );
      assertEquals( 3, eu.mcdB( 237, 42 ) );
      assertEquals( 1, eu.mcdB( 23, 10 ) );
      assertEquals( 8, eu.mcdB( 128, 8 ) );
   }

}
