package uba.algo3.practica;

public class Mcd {

   public int mcdA( int a, int b ) {
      
      while ( a != b ) {
         
         if ( a < b ) {
            b = b - a;
         } else {
            a = a - b;
         }
      }

      return a;
   }

   public int mcdB( int num1, int num2 ) {
      int mcd = 0, min;

      if ( num1 < num2 ) {
         min = num1;
      } else {
         min = num2;
      }

      for ( int i = 1; i <= min; i++ ) {
         if ( num1 % i == 0 && num2 % i == 0 ) {
            mcd = i;
         }
      }

      return mcd;

   }
   
}
