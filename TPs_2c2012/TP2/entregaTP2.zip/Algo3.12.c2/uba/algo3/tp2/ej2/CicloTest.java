package uba.algo3.tp2.ej2;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import org.junit.Test;

public class CicloTest
{
	  static Ciclo c;
	  static ArrayList<Valla> aristas;
	  
	  @Test
	  public void SuperficieTest()
	  {

		  aristas = Utils.parseVallas("2 2 - 2 2;2 2 | 1 2;2 3 - 3 2;5 1 | 2 2;4 1 - 1 2;4 1 | 1 2");
		  assertEquals(4, (new Ciclo(aristas).calcularSuperficie()));
		  
		  //test para cuando extendemos valla al sur despues y oeste antes
		  aristas = Utils.parseVallas("1 1 | 9 2;1 10 - 5 2;6 8 | 2 2;4 8 - 2 2;4 4 | 4 2;4 4 - 2 2;6 1 | 3 2;1 1 - 5 2");
		  assertEquals(37, (new Superficie(aristas,1)).calcularSuperficieResguardada());
	 
		  //Ejemplo L invertida (test para cuando extendemos valla al norte despues):
		  aristas = Utils.parseVallas("2 2 | 2 2;0 4 - 2 2;0 4 | 2 2;0 6 - 4 2;4 2 | 4 2;2 2 - 2 2");
		  assertEquals(12, (new Superficie(aristas,1)).calcularSuperficieResguardada());
		   
		  //test oeste despues
		  aristas = Utils.parseVallas("2 1 | 9 2;1 10 - 1 2;1 8 | 2 2;0 8 - 1 2;0 8 | 4 2;0 12 - 4 2;4 1 | 11 2;2 1 - 2 2");
		  assertEquals(28, (new Superficie(aristas,1)).calcularSuperficieResguardada());

		  //Test para cuando extendemos valla al este despues
		  aristas = Utils.parseVallas("2 2 | 2 2;2 4 - 4 2;6 4 | 4 2;6 8 - 2 2;8 2 | 6 2;2 2 - 6 2");
		  assertEquals(20, (new Superficie(aristas,1)).calcularSuperficieResguardada());
 
		  //Test para sur antes,este antes y norte antes
		  aristas = Utils.parseVallas("2 2 | 8 2;2 2 - 2 2;4 2 | 6 2;4 8 - 6 2;10 4 | 4 2;8 4 - 2 2;6 2 | 4 2;6 6 - 2 2;8 4 | 2 2;2 10 - 10 2;12 2 | 8 2;6 2 - 6 2");
		  assertEquals(56, (new Superficie(aristas,1)).calcularSuperficieResguardada());

		  aristas = Utils.parseVallas("2 2 | 2 2;2 4 - 2 2;4 4 | 2 2;0 6 - 4 2;0 6 | 6 2;0 12 - 3 2;3 10 | 2 2;2 10 - 1 2;2 8 | 2 2;2 8 - 4 2;6 2 | 6 2;2 2 - 4 2");
		  assertEquals(34, (new Superficie(aristas,1)).calcularSuperficieResguardada());

		  //test "z" (valla este continua) invertida despues
	      aristas = Utils.parseVallas( "2 2 | 2 1;2 4 - 2 1;4 4 | 2 1;4 6 - 4 1;8 4 | 2 1;6 4 - 2 1;6 2 | 2 1;2 2 - 4 1");
	      assertEquals(16,(new Superficie(aristas,1)).calcularSuperficieResguardada());

		  //test "z" (este continua) invertida antes
	      aristas = Utils.parseVallas( "6 2 | 2 1;2 2 - 4 1;2 2 | 2 1;2 4 - 2 1;4 4 | 2 1;4 6 - 4 1;8 4 | 2 1;6 4 - 2 1");
	      assertEquals(16,(new Ciclo(aristas)).calcularSuperficie());

		  
		  //test oeste1 continua despues
	      aristas = Utils.parseVallas( "6 4 - 2 1;6 2 | 2 1;2 2 - 4 1;2 2 | 2 1;2 4 - 2 1;4 4 | 2 1;4 6 - 4 1;8 4 | 2 1");
	      assertEquals(16,(new Ciclo(aristas)).calcularSuperficie());
	      
		  //test oeste1 continua antes
	      aristas = Utils.parseVallas( "4 4 | 2 1;4 6 - 4 1;8 4 | 2 1;6 4 - 2 1;6 2 | 2 1;2 2 - 4 1;2 2 | 2 1;2 4 - 2 1");
	      assertEquals(16,(new Ciclo(aristas)).calcularSuperficie());

	      //test oeste2 continua despues
	      aristas = Utils.parseVallas( "2 2 | 2 1;2 4 - 6 1;8 2 | 2 1;6 2 - 2 1;6 0 | 2 1;4 0 - 2 1;4 0 | 2 1;2 2 - 2 1");
	      //assertEquals(16,(new Ciclo(aristas)).calcularSuperficie());
	      
	      //test oeste2 continua antes
	      aristas = Utils.parseVallas( "2 2 | 2 1;2 4 - 6 1;8 2 | 2 1;6 2 - 2 1;6 0 | 2 1;4 0 - 2 1;4 0 | 2 1;2 2 - 2 1");
	      assertEquals(16,(new Ciclo(aristas)).calcularSuperficie());
	      
	      aristas = Utils.parseVallas( "4 0 | 2 1;2 2 - 2 1;2 2 | 2 1;2 4 - 6 1;8 2 | 2 1;6 2 - 2 1;6 0 | 2 1;4 0 - 2 1");
	      assertEquals(16,(new Ciclo(aristas)).calcularSuperficie());
	      
	      		  //test sur1 continua ambos lados despues
	      aristas = Utils.parseVallas( "2 2 | 6 1;2 8 - 2 1;4 6 | 2 1;4 6 - 2 1;6 4 | 2 1;4 4 - 2 1;4 2 | 2 1;2 2 - 2 1");
	      assertEquals(16,(new Ciclo(aristas)).calcularSuperficie()); 
	      

		  
		  //test norte1 continua ambos lados despues
	      aristas = Utils.parseVallas( "2 2 | 2 1;0 4 - 2 1;0 4 | 2 1;0 6 - 2 1;2 6 | 2 1;2 8 - 2 1;4 2 | 6 1;2 2 - 2 1");
	      assertEquals(16,(new Ciclo(aristas)).calcularSuperficie()); 
	      

		  //COMIENZO TESTS PARA FIGURAS PEGADAS POR VERTICES
		  //-------------------------------------------------------------------------------------
		  aristas = Utils.parseVallas("4 4 | 2 1;4 6 - 2 1;4 6 | 2 1;2 6 - 2 1;2 6 | 2 1;2 8 - 2 1;6 6 | 2 1;6 6 - 2 1;6 8 - 2 1;8 6 | 2 1;6 4 | 2 1;6 4 - 2 1;8 2 | 2 1;6 2 - 2 1;6 2 | 2 1;4 4 - 2 1;2 2 | 2 1;2 2 - 2 1;2 4 - 2 1;4 2 | 2 1");
		  assertEquals(20,(new Superficie(aristas,1)).calcularSuperficieResguardada());
		  
		  aristas = Utils.parseVallas("6 0 | 20 1;6 0 - 4 1;10 0 | 20 1;6 20 - 4 1;6 20 | 2 1;4 20 - 2 1;4 20 | 2 1;4 22 - 2 1;4 18 | 2 1;2 18 - 2 1;2 18 | 2 1;2 20 - 2 1");
		  assertEquals(88,(new Superficie(aristas,1)).calcularSuperficieResguardada());
		  //-------------------------------------------------------------------------------------	  
		  //FIN TESTS PARA FIGURAS PEGADAS POR VERTICES

	  }
}
