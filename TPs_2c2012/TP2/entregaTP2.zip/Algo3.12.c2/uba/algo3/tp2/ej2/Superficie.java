package uba.algo3.tp2.ej2;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Superficie
{
	private HashMap<Coordenadas, Vallas> grafo;
	private ArrayList<Ciclo> ciclos;
	private ArrayList<ArrayList<Valla>> recorridos_sin_dividir;
	private int saltoLangosta;
	
	public ArrayList<Ciclo> getCiclos()
	{
		return ciclos;
	}
	public int getSaltoLangosta()
	{
		return saltoLangosta;
	}
	public void setSaltoLangosta(int saltoLangosta)
	{
		this.saltoLangosta = saltoLangosta;
	}
	
	public int calcularSuperficieResguardada()
	{
		int superficie = 0;
		for(Ciclo c : ciclos)
		{
			superficie = superficie + c.calcularSuperficie();
		}
		
		return superficie;
	}
	
	public Superficie(ArrayList<Valla> vallas, int saltoLangosta)
	{
		super();

		this.saltoLangosta = saltoLangosta;
		ciclos = null;
		recorridos_sin_dividir = new ArrayList<ArrayList<Valla>>();
		
		dividirVallas(vallas);//O(vallas^2)..al dividirlas, el tama�o del arreglo queda en vallas^2, por lo que recorrer el arreglo de ahora en mas es vallas^2
		
		crearGrafo(vallas);//Crea el grafo y filtra las vallas que tienen altura menor que lo que saltan las langostas; O(vallas^2)
		
		eliminarVallasFueraDeCiclos();//O(vallas^2*log(vallas^2))
		
		obtenerCiclosSinSubciclos();
		
	}
	
	private void obtenerCiclosSinSubciclos()
	{

		Collection<Coordenadas> unsorted = grafo.keySet();
		List<Coordenadas> myList = new ArrayList<Coordenadas>(unsorted);
		Collections.sort(myList);//O(vallas^2*log(vallas^2))
		
		ArrayList<Valla> recorrido_sin_dividir;
		ciclos = new ArrayList<Ciclo>();
		for(Coordenadas coord : myList)//O(nodos) = O(vallas^2)..supongamos que lo podemos hacer en O(vallas), como si no las dividieramos (es facil arreglarlo haciendo q cuando dividimos las vallas, nos guardamos 1 solo nodo)
		{

			if(estaEnOtroCiclo(coord))//O(vallas)
			{
				recorrido_sin_dividir = obtenerContornoCiclo(coord, new ArrayList<Valla>(),1);//O(2*vallas_del_ciclo) = O(vallas_del_ciclo);
				
				if(recorrido_sin_dividir != null)
				{
					recorridos_sin_dividir.add(recorrido_sin_dividir);
					//SUBDIVIDIR FIGURAS PEGADAS POR VALLAS DEL CICLO
					ArrayList<ArrayList<Valla>> recorridos = subdividir_figuras_pegadas_por_aristas((ArrayList<Valla>) recorrido_sin_dividir.clone());//O(vallas^3)
					for(ArrayList<Valla> recorrido : recorridos)
					{
						if(recorrido.size() > 3)
						{
								unir_vallas_contiguas(recorrido);
								Ciclo nuevo_ciclo = new Ciclo(recorrido);//O(vallas_del_ciclo^3)
								ciclos.add(nuevo_ciclo);
						}
					}
				}
			}
		}
	}

	private void unir_vallas_contiguas(ArrayList<Valla> recorrido)
	{
		Valla anterior, actual,valla_unida;
		anterior = recorrido.get(0);
		for(int i = 1;i < recorrido.size();i++)
		{
			actual = recorrido.get(i);
			valla_unida = Valla.unirValla(anterior, actual);
			if(valla_unida != null)
			{
				recorrido.remove(i);
				recorrido.remove(i-1);
				recorrido.add(i-1,valla_unida);
				
				actual = valla_unida;
				valla_unida = null;
				i--;
			}
			anterior = actual;
		}
		
	}
	private ArrayList<ArrayList<Valla>> subdividir_figuras_pegadas_por_aristas(
			ArrayList<Valla> recorrido)
	{
		Valla v1,v2;
		ArrayList<ArrayList<Valla>> res = null,res2 = null;
		ArrayList<Valla> nuevo_recorrido;

		if(recorrido == null)
		{
			return new ArrayList<ArrayList<Valla>>();
		}
		
		for(int i = 0;i < recorrido.size();i++)//O(vallas)
		{
			v1 = recorrido.get(i);
			for(int j = i+1;j < recorrido.size();j++)//O(vallas)
			{
				v2 = recorrido.get(j);
				if(v1.equals(v2))
				{
					int ii = i;
					int jj = j;
					Valla temp1 = recorrido.get(jj-1);//O(1)
					Valla temp2 = recorrido.get(ii+1);//O(1)
					while(ii < jj && temp1.equals(temp2))//O(1)
					{
						jj--;
						ii++;
						temp1 = recorrido.get(jj-1);//O(1)
						temp2 = recorrido.get(ii+1);//O(1)
					}
					//quiere decir que hay 2 figuras pegadas por esa misma valla
					nuevo_recorrido = new ArrayList<Valla>();
					
					nuevo_recorrido.addAll(recorrido.subList(0, i));
					nuevo_recorrido.addAll(recorrido.subList(j+1, recorrido.size()));
					recorrido.subList(jj, recorrido.size()).clear();
					recorrido.subList(0, ii+1).clear();
					//ultimas 4 toman O(vallas), pero se ejecutan 1 sola vez en cada llamada a la funcion
					
					res = subdividir_figuras_pegadas_por_aristas(recorrido);
					res2 = subdividir_figuras_pegadas_por_aristas(nuevo_recorrido);
					res.addAll(res2);

					break;
				}
			}
			
		}
		
		if(res == null)
		{
			res = new ArrayList<ArrayList<Valla>>();		
			res.add(recorrido);
		}
		return res;
	}
	private boolean estaEnOtroCiclo(Coordenadas coord)
	{
		for(Ciclo c : ciclos)
		{
			if(c.pertenece(coord))
			{
				return false;
			}
		}//O(vallas)
		for(ArrayList<Valla> recorrido : recorridos_sin_dividir)
		{
			if(perteneceARecorrido(coord,recorrido))
			{
				return false;
			}
		}//O(vallas)
		return true;
	}
	private boolean perteneceARecorrido(Coordenadas coord,
			ArrayList<Valla> recorrido)
	{
		for(Valla v : recorrido)
		{
			if(v.getExtremo1().equals(coord) || v.getExtremo2().equals(coord))
			{
				return true;
			}
		}
		return false;
	}
	private ArrayList<Valla> obtenerContornoCiclo(Coordenadas c_param, ArrayList<Valla> recorrido_param, int sentido_param)
	{
		ArrayList<Valla> recorrido = recorrido_param;
		if(estoyEnCiclo(recorrido))
		{
			recorrido.remove(recorrido.size()-1);
			recorrido.remove(recorrido.size()-1);
			return recorrido;
		}
		int sentido = sentido_param;
		Coordenadas c = c_param;
		Vallas vs = grafo.get(c);
		Valla nueva_valla = null;
		if(sentido == 1)
		{
			//Venia subiendo..
			nueva_valla = vs.irOeste(c);
			sentido = -2;
			if(nueva_valla == null)
			{
				nueva_valla = vs.irNorte(c);
				sentido = 1;
				if(nueva_valla == null)
				{
					nueva_valla = vs.irEste(c);
					sentido = 2;
				}
			}
		}
		else if(sentido == -1)
		{
			//Venia en sentido sur..osea, bajando
			nueva_valla = vs.irEste(c);
			sentido = 2;
			if(nueva_valla == null)
			{
				nueva_valla = vs.irSur(c);
				sentido = -1;
				if(nueva_valla == null)
				{
					nueva_valla = vs.irOeste(c);
					sentido = -2;
				}
			}
		} else if(sentido == -2)
		{
			//venia yendo para el oeste
			nueva_valla = vs.irSur(c);
			sentido = -1;
			if(nueva_valla == null)
			{
				nueva_valla = vs.irOeste(c);
				sentido = -2;
				if(nueva_valla == null)
				{
					nueva_valla = vs.irNorte(c);
					sentido = 1;
				}
			}
		} else if(sentido == 2)
		{
			//venia yendo para el este
			nueva_valla = vs.irNorte(c);
			sentido = 1;
			if(nueva_valla == null)
			{
				nueva_valla = vs.irEste(c);
				sentido = 2;
				if(nueva_valla == null)
				{
					nueva_valla = vs.irSur(c);
					sentido = -1;
				}
			}

		}
		
		if(nueva_valla != null)
		{
			recorrido.add(nueva_valla);
			recorrido = obtenerContornoCiclo(nueva_valla.obtenerExtremo(c), recorrido, sentido);//se podria haber hecho una version iterativa en vez de recursiva del algoritmo, despues si hay tiempo se modifica!
			return recorrido;
		}
		else
		{
			return null;
		}
	}
	
	private boolean estoyEnCiclo(ArrayList<Valla> recorrido)
	{
		if(recorrido.size() > 3 && recorrido.get(recorrido.size()-2).estaContenida( recorrido.get(0) ) && recorrido.get(recorrido.size()-1).estaContenida(recorrido.get(1)) )
		{
			return true;
		}
		return false;
	}
	
	private void eliminarVallasFueraDeCiclos()
	{
		
        Collection<Vallas> unsorted = grafo.values();
        List<Vallas> vallas = new ArrayList<Vallas>(unsorted);
        Collections.sort(vallas);//O(vallas^2 * log(vallas^2))

		for(Vallas vs : vallas)//O(vallas^2)
		{	
			Coordenadas c = vs.getCoordenadas();
			
			if(vs.cantidad() == 0)
			{
				grafo.remove(c);//O(1)
			}		
			if(vs.cantidad() == 1)
			{
				Valla v = vs.getVallas().get(0);//O(1)
				Coordenadas otro_extremo = v.obtenerExtremo(c);//O(1)
				grafo.remove(c);//O(1) (Bajo ciertas condiciones...)
				vs = grafo.get(otro_extremo);//O(1);
				vs.eliminarValla(v);//O(1)
			}
		}//O(vallas^2)
	}
	
	private void crearGrafo(ArrayList<Valla> vallas)
	{
		grafo = new LinkedHashMap<Coordenadas, Vallas>();
		Coordenadas p,p2;
		Vallas vs,vs2;
		for(Valla a : vallas)//O(vallas^2)
		{
			
			if(a.getAltura() >= saltoLangosta)
			{
				p = a.getExtremo1();//O(1)
				p2 = a.getExtremo2();//O(1)
				vs = grafo.get(p);//O(1)
				vs2 = grafo.get(p2);//O(1)
				
				if(vs != null)
				{
					vs.agregarValla(a);//O(1)
				}
				else
				{
					vs = new Vallas(p,a);//O(1)
				}
				
				if(vs2 != null)
				{
					vs2.agregarValla(a);//O(1)
				}
				else
				{
					vs2 = new Vallas(p2,a);//O(1)
				}
				
				grafo.put(p2, vs2);//O(1)
				grafo.put(p, vs);//O(1)
			}
		}
		
	}
	
	private void dividirVallas(ArrayList<Valla> vallas)
	{
		Coordenadas a1_e1, a1_e2, a2_e1, a2_e2;
		Valla sub1, sub2;
		Valla a1,a2;
		int i = 0,j=0;
		
		while(i < vallas.size())//O(vallas)
		{
			a1 = vallas.get(i);
			
			while(j < vallas.size())//O(vallas)
			{
				a2 = vallas.get(j);
				
				a1_e1 = a1.getExtremo1();//O(1)
				a1_e2 = a1.getExtremo2();//O(1)
				
				a2_e1 = a2.getExtremo1();//O(1)
				a2_e2 = a2.getExtremo2();//O(1)

				if(a1.esVertical())//O(1)
				{			
					if( (a1_e1.mismaPosicionX(a2_e1) || a1_e1.mismaPosicionX(a2_e2)) || (a2_e1.tieneMenorX(a1_e1) && a1_e1.tieneMenorX(a2_e2) ))//preguntar por la posicion X de a1_e1 o a1_e2 es lo mismo al ser una valla vertical
					{
						//osea, estan en misma posicion horizontal y por lo tanto puede ser que la este "partiendo": |-
						if(a1_e1.tieneMenorY(a2_e1) && a2_e1.tieneMenorY(a1_e2))
						{
							vallas.remove(i);//O(1) (Amortizado)
							sub1 = new Valla(a1_e1, new Coordenadas(a1_e1.getX(), a2_e1.getY()), a1.getAltura());//O(1)
							sub2 = new Valla(new Coordenadas(a1_e1.getX(), a2_e1.getY()), a1_e2, a1.getAltura());//O(1)
							vallas.add(i,sub1);//O(1) (Amortizado)
							vallas.add(i+1,sub2);//O(1) (Amortizado)
							i--;
							break;
						}
					}
				}
				if(!a1.esVertical())//osea, la valla es horizontal
				{
					if( (a1_e1.mismaPosicionY(a2_e1) || a1_e1.mismaPosicionY(a2_e2)) || (a2_e1.tieneMenorY(a1_e1) && a1_e1.tieneMenorY(a2_e2) ))//preguntar por la posicion Y de a1_e1 o a1_e2 es lo mismo al ser una valla horizontal
					{
						//osea, esta en misma posicion vertical, por lo tanto puede ser que la este partiendo: _|_
						if(a1_e1.tieneMenorX(a2_e1) && a2_e1.tieneMenorX(a1_e2))
						{
							vallas.remove(i);
							sub1 = new Valla(a1_e1, new Coordenadas(a2_e1.getX(), a1_e1.getY()), a1.getAltura());
							sub2 = new Valla(new Coordenadas(a2_e1.getX(),a1_e1.getY()), a1_e2, a1.getAltura());
							vallas.add(i,sub1);//O(1) (Amortizado)
							vallas.add(i+1,sub2);//O(1) (Amortizado)
							i--;
							break;
						}
					}
				}
				
				j++;
			}
			j=0;
			i++;
		}
	}
	
	
}
