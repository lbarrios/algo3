package uba.algo3.tp2.ej2;

public class Valla implements Comparable<Valla>
{

	private Coordenadas extremo1;
	private Coordenadas extremo2;
	private int altura;
	private boolean esVertical;

	public Valla(Coordenadas extremo1, Coordenadas extremo2, int altura)
	{
		super();
		this.extremo1 = extremo1;
		this.extremo2 = extremo2;
		this.altura = altura;
		if(extremo1.getX() == extremo2.getX())
		{
			esVertical = true;
		}
		else
		{
			esVertical = false;
		}
	}

	public boolean esVertical()
	{
		return esVertical;
	}
	
	public Coordenadas obtenerExtremo(Coordenadas orig)
	{
		Coordenadas res = null;
		
		if(orig.equals(extremo1))
		{
			res = extremo2;
		}
		else if(orig.equals(extremo2))
		{
			res = extremo1;
		}
		
		return res;
	}
	
	public int getAltura()
	{
		return altura;
	}
	
	public Coordenadas obtenerCoordenadasEjeY()
	{
		Coordenadas res = new Coordenadas(extremo1.getY(),extremo2.getY());
		
		return res;
	}
	
	public Coordenadas obtenerCoordenadasEjeX()
	{
		Coordenadas res = new Coordenadas(extremo1.getX(),extremo2.getX());
		
		return res;
	}

	public int compareTo(Valla o)
	{
		return (this.extremo1.getX() - o.extremo1.getX() + this.extremo1.getY() - o.extremo1.getY());
	}

	public Coordenadas getExtremo1()
	{
		return extremo1;
	}
	
	public Coordenadas getExtremo2()
	{
		return extremo2;
	}

	public boolean voyOeste(Coordenadas pred)
	{
		if(!esVertical)
		{
			return this.obtenerExtremo(pred).getX() < pred.getX();
		}
		else
		{
			return false;
		}
	}
	
	public boolean voyEste(Coordenadas pred)
	{
		if(!esVertical)
		{
			return this.obtenerExtremo(pred).getX() > pred.getX();
		}
		else
		{
			return false;
		}
	}
	
	public boolean voyNorte(Coordenadas pred)
	{
		if(esVertical)
		{
			return this.obtenerExtremo(pred).getY() > pred.getY();
		}
		else
		{
			return false;
		}
	}
	
	public boolean voySur(Coordenadas pred)
	{
		if(esVertical)
		{
			return this.obtenerExtremo(pred).getY() < pred.getY();
		}
		else
		{
			return false;
		}
	}

	public static Valla unirValla(Valla valla1, Valla valla2)
	{
		if(valla1.esVertical() && valla2.esVertical())
		{
			if(valla1.getExtremo1().getX() == valla1.getExtremo2().getX())
			{
				if(valla1.getExtremo2().getY() == valla2.getExtremo1().getY())
				{
					return new Valla(valla1.getExtremo1(),valla2.getExtremo2(),valla1.getAltura());
				}
				
				if(valla1.getExtremo1().getY() == valla2.getExtremo2().getY())
				{
					return new Valla(valla2.getExtremo1(),valla1.getExtremo2(),valla1.getAltura());
				}
			}
				
		}
		
		if(!valla1.esVertical() && !valla2.esVertical())
		{
			if(valla1.getExtremo1().getY() == valla2.getExtremo2().getY())
			{
				if(valla1.getExtremo2().getX() == valla2.getExtremo1().getX())
				{
					return new Valla(valla1.getExtremo1(), valla2.getExtremo2(), valla1.getAltura());
				}
				
				if(valla1.getExtremo1().getX() == valla2.getExtremo2().getX())
				{
					return new Valla(valla2.getExtremo1(),valla1.getExtremo2(),valla1.getAltura());
				}
				
			}
		}
		
		return null;
	}

	public int hallarSentido(Valla valla)
	{
		if(this.esVertical())
		{
			if(this.getExtremo2().getY() == valla.getExtremo1().getY())
			{
				return 1;//sentido norte
			}
			
			if(this.getExtremo1().getY() == valla.getExtremo1().getY())
			{
				return -1;//sentido sur
			}
			
		}
		else
		{
			//era una valla horizontal
			if(this.getExtremo2().getX() == valla.getExtremo1().getX())
			{
				return 2;//sentido este
			}
			
			if(this.getExtremo1().getX() == valla.getExtremo1().getX())
			{
				return -2;
			}
		}
		
		return 0;
	}

	public boolean estaContenida(Valla valla)
	{
		if(valla.esVertical() && this.esVertical() && valla.getExtremo1().getX() == this.getExtremo1().getX())
		{
			//Si estan en la misma posicion y las 2 son verticales, me fijo sin la altura esta contenida.. 
			return this.getExtremo1().getY() >= valla.getExtremo1().getY() && this.getExtremo2().getY() <= valla.getExtremo2().getY();
		}
		
		if(!valla.esVertical() && !this.esVertical() && valla.getExtremo1().getY() == this.getExtremo1().getY())
		{
			return this.getExtremo1().getX() >= valla.getExtremo1().getX() && this.getExtremo2().getX() <= valla.getExtremo2().getX();
		}
		return false;
	}

	public String toString()
	{
		return "Valla ["
				+ (extremo1 != null ? extremo1 + ", " : "")
				+ (extremo2 != null ? extremo2 : "") + "]";
	}

}
