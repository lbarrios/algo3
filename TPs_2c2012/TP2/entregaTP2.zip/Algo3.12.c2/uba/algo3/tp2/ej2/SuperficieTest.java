package uba.algo3.tp2.ej2;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import org.junit.Test;

public class SuperficieTest
{
	  static ArrayList<Valla> aristas;
	  
	  @Test
	  public void SuperficieTest()
	  {
	     
		  //Ejemplo HOLA:
		  aristas = Utils.parseVallas("1 1 | 2 2;1 2 - 1 2;2 1 | 2 2;3 1 | 2 2;3 1 - 1 2;4 1 | 2 2;3 3 - 1 2;5 1 | 2 2;5 1 - 1 2;7 1 | 2 2;8 1 | 2 2;7 2 - 1 1;7 3 - 1 2");
		  assertEquals(3,(new Superficie(aristas,1)).calcularSuperficieResguardada());

		  //Ejemplo ciclo:
		  aristas = Utils.parseVallas("1 1 | 1 1;1 1 - 1 1;1 2 - 1 1;2 1 | 1 1; 1 2 | 1 1; 1 3 - 1 1; 2 2 | 1 1;2 3 | 1 1;1 3 | 1 1;1 4 - 1 1");
		  assertEquals(3,(new Superficie(aristas,1)).calcularSuperficieResguardada());

		  aristas = Utils.parseVallas("1 2 - 2 1;2 2 | 4 1;2 4 - 1 1;3 2 | 2 1");	  
		  assertEquals(2,(new Superficie(aristas,1)).calcularSuperficieResguardada());
		  
		  aristas = Utils.parseVallas("1 1 - 2 1; 1 1 | 2 1; 1 3 - 2 1; 3 3 | 2 1; 3 5 - 2 1; 5 2 | 3 1; 3 1 | 1 1; 3 2 - 2 1");
		  assertEquals(10,(new Superficie(aristas,1)).calcularSuperficieResguardada());
		  
		  aristas = Utils.parseVallas("1 2 - 2 1;2 0 | 4 1;3 2 | 3 1;2 4 - 2 1;4 4 | 1 1;3 5 - 1 1;10 2 - 3 1");
		  assertEquals(3,(new Superficie(aristas,1)).calcularSuperficieResguardada());
		 
		  aristas = Utils.parseVallas("5 5 | 1 1;5 1 | 1 1;4 3 | 1 1;3 3 - 1 1;2 2 | 3 1;1 1 | 5 1;1 1 - 4 1;2 2 - 3 1;3 4 - 1 1;2 5 - 3 1;1 6 - 4 1");
		  assertEquals(11,(new Superficie(aristas,1)).calcularSuperficieResguardada());
		  
		  //TEST "C" con un ciclo adentro
		  aristas = Utils.parseVallas("5 5 | 1 1;5 1 | 1 1;3 4 - 1 1;3 3 | 1 1;3 3 - 1 1;2 2 | 3 1;1 1 | 5 1;1 1 - 4 1;2 2 - 3 1;4 3 - 1 1;4 3 | 1 1;2 5 - 3 1;1 6 - 4 1");
		  assertEquals(12,(new Superficie(aristas,1)).calcularSuperficieResguardada());
		  
		  //TEST Espiral!
		  aristas = Utils.parseVallas("2 2 | 18 1;2 2 - 2 1;4 2 | 16 1;2 20 - 18 1;20 2 | 18 1;4 18 - 14 1;18 4 | 14 1;6 2 - 14 1;6 2 | 14 1;8 4 - 10 1;8 4 | 10 1;8 14 - 7 1;6 16 - 10 1;16 6 | 10 1;10 6 - 6 1;10 6 | 6 1;15 8 | 6 1;12 8 - 3 1;12 8 | 2 1;12 10 - 2 1;14 10 | 2 1;10 12 - 4 1");
		  assertEquals(194,(new Superficie(aristas,1)).calcularSuperficieResguardada());
		   
		  //TEST SIN CICLOS
		  aristas = Utils.parseVallas( "3 2 | 1 1;3 2 - 2 1;3 3 - 1 1;4 3 | 1 1;5 2 - 2 1");
	      assertEquals(0,(new Superficie(aristas,1)).calcularSuperficieResguardada());

	      
	      aristas = Utils.parseVallas( "1 1 | 1 1;1 1 - 3 1;1 2 - 1 1;2 2 | 1 1;2 3 - 1 1;3 2 | 1 1;3 2 - 1 1;4 1 | 1 1");
	     assertEquals(4,(new Superficie(aristas,1)).calcularSuperficieResguardada());
	      
	       
	      aristas = Utils.parseVallas("3 2 | 1 1;3 2 - 1 1;4 1 | 1 1;1 1 - 3 1;1 1 | 1 1;1 2 - 1 1;2 2 | 1 1;2 3 - 1 1");
	      assertEquals(4,(new Ciclo(aristas)).calcularSuperficie());
	  

        //Test vacio
        aristas = Utils.parseVallas( "" );
        assertEquals(0,(new Superficie(aristas,1)).calcularSuperficieResguardada());

        //Test cuadrado
        aristas = Utils.parseVallas( "1 1 | 1 1;1 1 - 1 1;2 1 | 1 1;1 2 - 1 1" );
        assertEquals(0,(new Superficie(aristas,2)).calcularSuperficieResguardada());
        assertEquals(1,(new Superficie(aristas,1)).calcularSuperficieResguardada());

        // Test 3 cuadrados b
        aristas = Utils.parseVallas( "1 1 | 5 1;1 6 - 5 1;1 1 - 5 1;6 1 | 5 1;2 2 | 3 1;2 5 - 3 1;2 2 - 3 1;5 2 | 3 1;3 3 | 1 1;3 3 - 1 1;3 4 - 1 1;4 3 | 1 1" );
        assertEquals(25,(new Superficie(aristas,1)).calcularSuperficieResguardada());

        // Test 3 cuadrados b' (diferente altura)
        aristas = Utils.parseVallas( "1 1 | 5 2;1 6 - 5 1;1 1 - 5 2;6 1 | 5 2;2 2 | 3 1;2 5 - 3 2;2 2 - 3 2;5 2 | 3 2;3 3 | 1 2;3 3 - 1 2;3 4 - 1 2;4 3 | 1 2" );
        assertEquals(1,(new Superficie(aristas,2)).calcularSuperficieResguardada());
        
        // Test borrar vallas sobrantes de rectangulo
        aristas = Utils.parseVallas( "0 1 - 3 1;1 2 - 3 1;1 1 | 2 1;3 0 | 2 1" );
        assertEquals(2,(new Superficie(aristas,1)).calcularSuperficieResguardada());
        
        // Test borrar vallas sobrantes de cuadrado
        aristas = Utils.parseVallas( "1 1 - 2 1;0 2 - 2 1;1 0 | 2 1;2 1 | 2 1" );
        assertEquals(1,(new Superficie(aristas,1)).calcularSuperficieResguardada());
	     
        // Test rectangulo con vallas sobrantes 
        aristas = Utils.parseVallas( "1 4 | 2 1;2 4 | 2 1;1 4 - 2 1;1 6 - 1 1;3 4 | 1 1" );
        assertEquals(2,(new Superficie(aristas,1)).calcularSuperficieResguardada());
        
        // Test varios cuadrados unidos 
        aristas = Utils.parseVallas( "1 1 | 3 1;2 1 | 3 1;3 1 | 3 1;4 1 | 1 1;1 1 - 3 1;1 2 - 3 1;1 3 - 2 1;1 4 - 2 1" );
        assertEquals(7,(new Superficie(aristas,1)).calcularSuperficieResguardada());

        //Test 2 cruces "rellenas" y un cuadrado
         aristas = Utils.parseVallas( "1 2 | 1 1;1 2 - 1 1;1 3 - 1 1;2 2 | 1 1;3 2 | 1 1;3 2 - 1 1;3 3 - 1 1;4 3 | 1 1;4 4 - 1 1;5 3 | 1 1;5 3 - 1 1;6 2 | 1 1;5 2 - 1 1;5 1 | 1 1;4 1 - 1 1;4 1 | 1 1;2 4 - 1 1;2 4 | 1 1;1 5 - 1 1;1 5 | 1 1;1 6 - 1 1;2 6 | 1 1;2 7 - 1 1;3 6 | 1 1;3 6 - 1 1;4 5 | 1 1;3 5 - 1 1;3 4 | 1 1" );
         assertEquals(11,(new Superficie(aristas,1)).calcularSuperficieResguardada());
          
        // Test cruz rellena
        aristas = Utils.parseVallas( "3 2 | 1 1;3 2 - 1 1;3 3 - 1 1;4 3 | 1 1;4 4 - 1 1;5 3 | 1 1;5 3 - 1 1;6 2 | 1 1;5 2 - 1 1;5 1 | 1 1;4 1 - 1 1;4 1 | 1 1");
        assertEquals(5,(new Superficie(aristas,1)).calcularSuperficieResguardada());

         // Test mitad de cruz rellena
          aristas = Utils.parseVallas( "1 1 | 1 1;1 1 - 3 1;1 2 - 1 1;2 2 | 1 1;2 3 - 1 1;3 2 | 1 1;3 2 - 1 1;4 1 | 1 1");
         assertEquals(4,(new Superficie(aristas,1)).calcularSuperficieResguardada());
         
        // Test 1/4 de cruz rellena
        aristas = Utils.parseVallas( "1 1 | 1 1;1 2 - 1 1;2 2 | 1 1;2 3 - 1 1;1 1 - 2 1;3 1 | 2 1");
        assertEquals(3,(new Superficie(aristas,1)).calcularSuperficieResguardada());
                  
        // Test 3 cuadrados a 
        aristas = Utils.parseVallas( "1 4 | 2 1;1 6 - 2 1;1 4 - 2 1;3 4 | 2 1;2 5 - 2 1;2 2 | 3 1;2 2 - 2 1;4 2 | 3 1;3 3 - 2 1;3 1 | 2 1;3 1 - 2 1;5 1 | 2 1");
        assertEquals(12,(new Superficie(aristas,1)).calcularSuperficieResguardada());
   
        // Test espiral compuesto
        aristas = Utils.parseVallas( "1 1 | 10 1;2 2 | 8 1;4 3 | 1 1;4 5 | 2 1;4 8 | 1 1;6 4 | 4 1;7 3 | 1 1;7 5 | 4 1;8 2 | 2 1;9 1 | 4 1;9 6 | 1 1;9 10 | 1 1;5 5 | 2 1;1 1 - 8 1;2 2 - 6 1;4 3 - 3 1;4 4 - 2 1;7 4 - 1 1;4 5 - 1 1;7 5 - 2 1;7 6 - 2 1;4 7 - 1 1;7 7 - 2 1;4 8 - 2 1;4 9 - 3 1;2 10 - 7 1;1 11 - 8 1" );
        assertEquals(42,(new Superficie(aristas,1)).calcularSuperficieResguardada());
       
        // Test rectangulo con cuadrado unido por arista
         aristas = Utils.parseVallas( "1 4 | 2 1;2 4 | 2 1;3 4 | 1 1;4 4 | 1 1;1 4 - 3 1;3 5 - 1 1;1 6 - 1 1" );
        assertEquals(3,(new Superficie(aristas,1)).calcularSuperficieResguardada());
       
        // Test cruz sobre cuadrado..
        aristas = Utils.parseVallas( "1 1 | 2 1;2 0 | 4 1;3 1 | 2 1;1 1 - 2 1;0 2 - 4 1;1 3 - 2 1" );
       assertEquals(4,(new Superficie(aristas,1)).calcularSuperficieResguardada()); 

       // Test varios cuadrados unidos con valla sobrante
       aristas = Utils.parseVallas( "1 1 | 2 1;2 1 | 2 1;3 1 | 2 1;1 1 - 3 1;1 2 - 2 1;1 3 - 2 1" );
        assertEquals(4,(new Superficie(aristas,1)).calcularSuperficieResguardada());
        
        // Test varios cuadrados unidos con valla sobrante
        aristas = Utils.parseVallas( "1 1 | 2 1;2 1 | 2 1;3 1 | 3 1;1 1 - 2 1;1 2 - 2 1;1 3 - 2 1" );
        assertEquals(4,(new Superficie(aristas,1)).calcularSuperficieResguardada());
        
         // Test varios cuadrados unidos con valla sobrante
          aristas = Utils.parseVallas( "1 1 | 2 1;2 1 | 2 1;3 1 | 2 1;1 1 - 2 1;1 2 - 2 1;0 3 - 3 1" );
          assertEquals(4,(new Superficie(aristas,1)).calcularSuperficieResguardada());
          
          // Test rectangulo con vallas sobrantes 
          aristas = Utils.parseVallas( "1 4 | 2 1;2 4 | 2 1;1 4 - 3 1;1 6 - 1 1;3 4 | 1 1" );
          assertEquals(2,(new Superficie(aristas,1)).calcularSuperficieResguardada());
          
          // Test cruz rellena con cuadrado 
          aristas = Utils.parseVallas( "1 3 | 1 1;2 2 | 1 1;2 4 | 1 1;3 5 | 1 1;4 5 | 1 1;5 4 | 1 1;6 3 | 1 1;5 2 | 1 1;4 1 | 1 1;3 1 | 1 1;3 1 - 1 1;2 2 - 1 1;4 2 - 1 1;1 3 - 1 1;5 3 - 1 1;1 4 - 1 1;2 5 - 1 1;3 6 - 1 1;4 5 - 1 1;5 4 - 1 1" );
          assertEquals(13,(new Superficie(aristas,1)).calcularSuperficieResguardada());
          
          // Test varios cuadrados unidos con valla sobrante
          aristas = Utils.parseVallas( "1 1 | 3 1;2 1 | 3 1;3 1 | 3 1;4 1 | 1 1;1 1 - 4 1;1 2 - 3 1;1 3 - 2 1;1 4 - 2 1" );
          assertEquals(7,(new Superficie(aristas,1)).calcularSuperficieResguardada());
        
          // Test varios cuadrados unidos con valla sobrante
          aristas = Utils.parseVallas( "0 0 | 3 1;2 1 | 2 1;3 1 | 2 1;1 1 - 2 1;1 2 - 2 1;1 3 - 2 1" );
          assertEquals(2,(new Superficie(aristas,1)).calcularSuperficieResguardada());
          
          // Test varios cuadrados unidos con valla sobrante    
          aristas = Utils.parseVallas( "1 1 | 2 1;2 1 | 2 1;3 1 | 2 1;1 1 - 2 1;0 2 - 3 1;1 3 - 2 1" );
         assertEquals(4,(new Superficie(aristas,1)).calcularSuperficieResguardada());
         
         // Test E-Existe
         aristas = Utils.parseVallas( "1 1 - 2 1;2 2 - 1 1;2 3 - 1 1;2 4 - 1 1;2 5 - 3 1;1 6 - 5 1;4 4 - 1 1;4 3 - 1 1;4 2 - 1 1;4 1 - 2 1;1 1 | 5 1;3 1 | 1 1;3 3 | 1 1;2 2 | 1 1;2 4 | 1 1;4 1 | 1 1;5 2 | 1 1;4 3 | 1 1;5 4 | 1 1;6 1 | 5 1");    
         assertEquals(17,(new Superficie(aristas,1)).calcularSuperficieResguardada());
         
         //Test I
         aristas = Utils.parseVallas( "7 1 | 1 1;8 2 | 1 1;7 3 | 1 1;8 4 | 1 1;9 4 | 1 1;10 3 | 1 1;9 2 | 1 1;10 1 | 1 1;7 1 - 3 1;7 2 - 1 1;7 3 - 1 1;7 4 - 3 1;9 3 - 1 1;9 2 - 1 1;8 5 - 1 1" ); 
         assertEquals(8,(new Superficie(aristas,1)).calcularSuperficieResguardada());
         
         // Test E-Existe, I 
         aristas = Utils.parseVallas( "1 1 - 2 1;2 2 - 1 1;2 3 - 1 1;2 4 - 1 1;2 5 - 3 1;1 6 - 5 1;4 4 - 1 1;4 3 - 1 1;4 2 - 1 1;4 1 - 2 1;1 1 | 5 1;3 1 | 1 1;3 3 | 1 1;2 2 | 1 1;2 4 | 1 1;4 1 | 1 1;5 2 | 1 1;4 3 | 1 1;5 4 | 1 1;6 1 | 5 1;7 1 | 1 1;8 2 | 1 1;7 3 | 1 1;8 4 | 1 1;9 4 | 1 1;10 3 | 1 1;9 2 | 1 1;10 1 | 1 1;7 1 - 3 1;7 2 - 1 1;7 3 - 1 1;7 4 - 3 1;9 3 - 1 1;9 2 - 1 1;8 5 - 1 1");    
         assertEquals(25,(new Superficie(aristas,1)).calcularSuperficieResguardada());
         
         // Test pino
         aristas = Utils.parseVallas( "1 1 - 2 1;1 2 - 1 1;2 3 - 1 1;3 4 - 1 1;4 3 - 1 1;5 2 - 1 1;3 2 - 1 1;4 1 - 2 1;1 1 | 1 1;2 2 | 1 1;3 3 | 1 1;4 3 | 1 1;5 2 | 1 1;6 1 | 1 1;4 1 | 1 1;3 1 | 1 1" );
         assertEquals(8,(new Superficie(aristas,1)).calcularSuperficieResguardada());
         
         // Test 4 espirales juntos
        aristas = Utils.parseVallas( "1 1 | 2 1;1 5 | 2 1;2 1 | 1 1;2 5 | 1 1;3 1 | 1 1;3 5 | 1 1;4 1 | 6 1;5 2 | 1 1;5 4 | 1 1;6 2 | 1 1;6 4 | 2 1;7 1 | 2 1;7 4 | 1 1;8 4 | 2 1;1 1 - 2 1;4 1 - 3 1;2 2 - 1 1;5 2 - 1 1;1 3 - 3 1;5 3 - 2 1;4 4 - 2 1;7 4 - 1 1;1 5 - 2 1;4 5 - 1 1;7 5 - 1 1;2 6 - 1 1;6 6 - 2 1;1 7 - 3 1" );
        assertEquals(5,(new Superficie(aristas,1)).calcularSuperficieResguardada());

       //Test doble espiral
       aristas = Utils.parseVallas( "1 3 | 2 1;2 3 | 1 1;3 1 | 3 1;3 5 | 7 1;4 1 | 5 1;4 7 | 4 1;5 1 | 4 1;5 7 | 1 1;5 9 | 1 1;6 2 | 2 1;6 7 | 1 1;7 7 | 1 1;7 10 | 1 1;8 3 | 1 1;8 9 | 3 1;9 3 | 2 1;10 2 | 4 1;11 1 | 5 1;11 7 | 1 1;12 6 | 1 1;3 1 - 1 1;5 1 - 6 1;6 2 - 4 2;1 3 - 1 1;8 3 - 1 1;2 4 - 1 1;6 4 - 2 1;1 5 - 2 1;5 5 - 4 1;4 6 - 6 1;11 6 - 1 1;4 7 - 1 1;6 7 - 1 1;11 7 - 1 1;5 8 - 1 1;7 8 - 4 1;5 9 - 3 1;5 10 - 2 1;4 11 - 3 1;3 12 - 5 1" );  
       assertEquals(52,(new Superficie(aristas,1)).calcularSuperficieResguardada()); 
	     
       // Test x punto y
       aristas = Utils.parseVallas( "1 1 - 1 1;4 1 - 6 1;1 2 - 1 1;4 2 - 1 1;7 2 - 3 1;2 3 - 2 1;5 3 - 1 1;8 3 - 2 1;2 4 - 2 1;5 4 - 1 1;7 4 - 3 1;1 5 - 1 1;4 5 - 1 1;7 5 - 1 1;9 5 - 1 1;1 6 - 1 1;4 6 - 1 1;7 6 - 1 1;9 6 - 1 1;1 1 | 1 1;1 5 | 1 1;2 1 | 2 1;2 4 | 2 1;3 3 | 1 1;4 1 | 2 1;4 4 | 2 1;5 1 | 1 1;5 3 | 1 1;5 5 | 1 1;6 1 | 3 1;7 1 | 1 1;7 4 | 2 1;8 3 | 1 1;8 5 | 1 1;9 3 | 1 1;9 5 | 1 1;10 1 | 2 1;10 4 | 2 1" );
       assertEquals(11,(new Superficie(aristas,1)).calcularSuperficieResguardada()); 
       
	     //Test ultimo
        aristas = Utils.parseVallas( "4 1 - 3 1;11 1 - 1 1;17 1 - 2 1;2 2 - 1 1;8 2 - 1 1;10 2 - 1 1;4 3 - 1 1;6 3 - 1 1;15 3 - 1 1;0 4 - 2 1;6 4 - 2 1;9 4 - 2 1;13 4 - 1 1;18 4 - 1 1;1 5 - 1 1;3 5 - 2 1;12 5 - 1 1;14 5 - 1 1;16 5 - 1 1;1 6 - 1 1;3 6 - 3 1;7 6 - 2 1;10 6 - 2 1;14 6 - 3 1;1 7 - 1 1;13 7 - 1 1;18 7 - 1 1;1 8 - 2 1;5 8 - 1 1;7 8 - 1 1;9 8 - 1 1;12 8 - 1 1;17 8 - 1 1;6 9 - 1 1;5 10 - 1 1;7 10 - 1 1;1 5 | 1 1;1 7 | 1 1;2 2 | 3 1;2 6 | 1 1;3 2 | 3 1;3 6 | 2 1;4 1 | 2 1;5 0 | 1 1;5 3 | 2 1;5 8 | 2 1;6 0 | 1 1;6 3 | 1 1;6 6 | 2 1;6 9 | 1 1;7 1 | 2 1;7 6 | 2 1;7 9 | 1 1;8 2 | 2 1;8 8 | 2 1;9 2 | 2 1;9 6 | 2 1;10 2 | 2 1;10 6 | 2 1;11 1 | 3 1;11 6 | 3 1;12 1 | 4 1;12 6 | 2 1;13 4 | 1 1;13 7 | 1 1;14 4 | 1 1;14 6 | 1 1;15 3 | 2 1;16 3 | 2 1;16 6 | 2 1;17 1 | 4 1;17 6 | 2 1;18 4 | 4 1;19 1 | 3 1" );
        assertEquals(68,(new Superficie(aristas,1)).calcularSuperficieResguardada()); 
        

	  }
}
