package uba.algo3.tp2.ej2;

import java.util.ArrayList;
import java.util.StringTokenizer;

public class Utils
{
	   public static ArrayList<Valla> parseVallas( String string )
	   {
		      StringTokenizer st1 = new StringTokenizer(string, ";");
		      String temp;
		      int x1,y1,x2,y2,altura;
		      Valla a;
		      
		      ArrayList<Valla> aristas = new ArrayList<Valla>();
		      while(st1.hasMoreTokens())
		      {
		    	 temp = st1.nextToken();
		    	 StringTokenizer st2 = new StringTokenizer(temp," ");

		    	 x1 = Integer.parseInt(st2.nextToken());
		    	 y1 = Integer.parseInt(st2.nextToken());
		    	 char orientation = st2.nextToken().charAt(0);
		    		 
		    	 if(orientation == '|')
		    	 {
		    		 x2 = x1;
		    		 y2 = y1 + Integer.parseInt(st2.nextToken());
		    	 }
		    	 else if(orientation == '-')
		    	 {
		    		 x2 = x1 + Integer.parseInt(st2.nextToken());
		    		 y2 = y1;
		    	 }
		    	 else
		    	 {
		    		 break;
		    	 }
		    	 
		    	 altura = Integer.parseInt(st2.nextToken());
		         
		    	 a = new Valla(new Coordenadas(x1,y1), new Coordenadas(x2,y2) ,altura);
		    	 
		    	 aristas.add(a);
		      }
		      
		      //Collections.sort(aristas);
		      
		      return aristas;
	}
}
