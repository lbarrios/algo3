package uba.algo3.tp2.ej2;


public class Coordenadas implements Comparable<Coordenadas>
{
	private int x;
	private int y;
	
	public Coordenadas(int x, int y)
	{
		super();
		this.x = x;
		this.y = y;
	}
	
	public int getX()
	{
		return x;
	}
	public void setX(int x)
	{
		this.x = x;
	}
	public int getY()
	{
		return y;
	}
	public void setY(int y)
	{
		this.y = y;
	}

	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + x;
		result = prime * result + y;
		return result;
	}

	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Coordenadas other = (Coordenadas) obj;
		if (x != other.x)
			return false;
		if (y != other.y)
			return false;
		return true;
	}

	public int compareTo(Coordenadas o)
	{
		return this.getX() - o.getX() + this.getY() - o.getY();
	}
	
	public boolean mismaPosicionX(Coordenadas otro)
	{
		return this.getX() == otro.getX();
	}

	public boolean tieneMenorY(Coordenadas otro)
	{
		return this.getY() < otro.getY();
	}

	public boolean tieneMenorX(Coordenadas otro)
	{
		return this.getX() < otro.getX();
	}

	public boolean mismaPosicionY(Coordenadas otro)
	{
		return this.getY() == otro.getY();
	}

	public String toString()
	{
		return "(x=" + x + ", y=" + y + ")";
	}
	
}
