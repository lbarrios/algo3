package uba.algo3.tp2.ej2;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import org.junit.Test;

public class SuperficieCatedraTest {

	   @Test
	   public void fileWritingRunTest() throws IOException {
	      // Con este test se lee el archivo de entrada proporcioando por la catedra 
	      // y se genera la salida.
	      
	      BufferedReader is = new BufferedReader( new InputStreamReader( getClass().getResourceAsStream( "Tp2Ej2.in" ) ) );
	      BufferedWriter os = new BufferedWriter( new FileWriter( getClass().getResource( "" ).getPath() + "Tp2Ej2.out" ) );

	      String line;
	      while ( ( line = is.readLine() ) != null ) {
	         os.append( run( line, is.readLine() ) ).append( '\n' );
	      }
	      os.close();
	      
	   }

	   @Test
	   public void fileTestingRunTest() throws IOException {
	      // Con este test se compara un archivo de entrada con el formato de la catedra 
	      // contra otro archivo con valores esperados.
	      BufferedReader source  = new BufferedReader( new InputStreamReader( getClass().getResourceAsStream( "Tp2Ej2.in" ) ) );
	      BufferedReader control = new BufferedReader( new InputStreamReader( getClass().getResourceAsStream( "Tp2Ej2.out" ) ) );
	      
	      String line;
	      while ( ( line = source.readLine() ) != null ) {
	         assertEquals( control.readLine(), run( line, source.readLine() ) );
	      }
	      
	   }

	   private String run( String a, String b ) {
	      
	      int res = new Superficie(Utils.parseVallas(b),Integer.parseInt(a)).calcularSuperficieResguardada();
	      
	      return String.valueOf(res);
	   }
	      
	}