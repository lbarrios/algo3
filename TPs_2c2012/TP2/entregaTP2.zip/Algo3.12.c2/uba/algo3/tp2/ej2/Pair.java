package uba.algo3.tp2.ej2;

public class Pair implements Comparable<Pair>
{

	int x;
	int y;
	
	public Pair(int x, int y)
	{
		super();
		this.x = x;
		this.y = y;
	}
	
	
	public Pair(Coordenadas coordenadas)
	{
		super();
		this.x = coordenadas.getX();
		this.y = coordenadas.getY();
	}
	
	public Pair()
	{
		x = Integer.MAX_VALUE;
		y = Integer.MAX_VALUE;
	}

	public int getX()
	{
		return x;
	}
	
	public void setX(int x)
	{
		this.x = x;
	}
	
	public int getY()
	{
		return y;
	}
	
	public void setY(int y)
	{
		this.y = y;
	}

	public int compareTo(Pair arg0)
	{
		return this.getX() - arg0.getX();
	}

	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + x;
		result = prime * result + y;
		return result;
	}

	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pair other = (Pair) obj;
		if (x != other.x)
			return false;
		if (y != other.y)
			return false;
		return true;
	}
	
	
}