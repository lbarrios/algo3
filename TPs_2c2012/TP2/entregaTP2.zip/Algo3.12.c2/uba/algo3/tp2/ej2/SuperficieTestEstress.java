package uba.algo3.tp2.ej2;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import org.junit.Test;

public class SuperficieTestEstress
{
	   
	@Test
	public void TestEscalera()
	{

		ArrayList<Valla> aristas = new ArrayList<Valla>();
		long l, tiempo_promedio = 0;
		int iter1 = 30, iter2 = 20;

		FileWriter fstream;
		BufferedWriter out = null;
		Coordenadas actual, anterior = new Coordenadas(0, 2);
		Valla new_valla;

		try
		{
			fstream = new FileWriter("outEj3.txt");
			out = new BufferedWriter(fstream);
		} catch (IOException e)
		{
			e.printStackTrace();
		}
		for (int j = 1; j <= iter2; j++)
		{
			for (int i = 1; i <= iter1; i++)
			{
				actual = new Coordenadas(anterior.getX(), anterior.getY() + 2);
				new_valla = new Valla(anterior, actual, 1);
				aristas.add(new_valla);

				anterior = actual;

				actual = new Coordenadas(anterior.getX() + 2, anterior.getY());
				new_valla = new Valla(anterior, actual, 1);
				aristas.add(new_valla);

				anterior = actual;
			}

			actual = new Coordenadas(anterior.getX() + 2, anterior.getY());
			new_valla = new Valla(anterior, actual, 1);
			aristas.add(new_valla);

			anterior = actual;

			for (int i = 1; i <= iter1; i++)
			{
				actual = new Coordenadas(anterior.getX(), anterior.getY() - 2);
				new_valla = new Valla(actual, anterior, 1);
				aristas.add(new_valla);

				anterior = actual;

				actual = new Coordenadas(anterior.getX() - 2, anterior.getY());
				new_valla = new Valla(actual, anterior, 1);
				aristas.add(new_valla);

				anterior = actual;

			}

			actual = new Coordenadas(anterior.getX() - 2, anterior.getY());
			new_valla = new Valla(actual, anterior, 1);
			aristas.add(new_valla);

			for (int i = 1; i <= 10; i++)
			{
				l = System.currentTimeMillis();
				(new Superficie(aristas, 1)).calcularSuperficieResguardada();
				tiempo_promedio += (int) (System.currentTimeMillis() - l);
			}
			try
			{
				out.write(aristas.size() + " " + tiempo_promedio / 10 + "\n");
			} catch (IOException e)
			{
				e.printStackTrace();
			}

			tiempo_promedio = 0;

			System.out.println("Iteracion: " + j);
		}

		try
		{
			out.close();
		} catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	
	
	@Test
	public void TestEspiral()
	{

		ArrayList<Valla> aristas = new ArrayList<Valla>();
		long l, tiempo_promedio = 0;
		int iter2 = 30,iter1=10;

		FileWriter fstream;
		BufferedWriter out = null;

		try
		{
			fstream = new FileWriter("outEj3E.txt");
			out = new BufferedWriter(fstream);
		} catch (IOException e)
		{
			e.printStackTrace();
		}
		for (int j = 1; j <= iter2; j++)
		{
			
			aristas = crearEspiral(iter1);
			iter1+=10;
			for (int i = 1; i <= 10; i++)
			{
				l = System.currentTimeMillis();
				(new Superficie(aristas, 1)).calcularSuperficieResguardada();
				tiempo_promedio += (int) (System.currentTimeMillis() - l);
			}
			try
			{
				out.write(aristas.size() + " " + tiempo_promedio / 10 + "\n");
			} catch (IOException e)
			{
				e.printStackTrace();
			}

			tiempo_promedio = 0;

			System.out.println("Iteracion: " + j);
		}

		try
		{
			out.close();
		} catch (IOException e)
		{
			e.printStackTrace();
		}
	}
   
   private ArrayList<Valla> crearEspiral(int j)
	{
		Coordenadas coord_ant1 = new Coordenadas(j*2,j*2+2);
		Coordenadas coord_ant2 = new Coordenadas(j*2+1,j*2+2);
		Coordenadas temp,temp1 = null,temp2 = null;

		ArrayList<Valla> aristas = new ArrayList<Valla>();
		aristas.add(new Valla(coord_ant1,coord_ant2,1));
		temp = new Coordenadas(coord_ant2.getX(),coord_ant2.getY()-1);
		aristas.add(new Valla(temp,coord_ant2,1));
		coord_ant2 = temp;
		temp = new Coordenadas(coord_ant1.getX(),coord_ant1.getY()-2);
		aristas.add(new Valla(temp,coord_ant1,1));
		coord_ant1 = temp;
		int incr1 = 3;
		int incr2 = 1;
		for(int i = 1; i <= j; i++)
		{
			//agrego valla horizontal
			temp2 = new Coordenadas(coord_ant2.getX() + incr2,coord_ant2.getY());
			temp1 = new Coordenadas(coord_ant1.getX() + incr1, coord_ant1.getY());
			aristas.add(new Valla(coord_ant1,temp1,1));
			aristas.add(new Valla(coord_ant2,temp2,1));
			
			coord_ant1 = temp1;
			coord_ant2 = temp2;
			
			incr1++;
			incr2++;
			
			//valla vertical
			
			temp2 = new Coordenadas(coord_ant2.getX(),coord_ant2.getY() + incr2);
			temp1 = new Coordenadas(coord_ant1.getX(), coord_ant1.getY() + incr1);
			aristas.add(new Valla(coord_ant1,temp1,1));
			aristas.add(new Valla(coord_ant2,temp2,1));
			
			coord_ant1 = temp1;
			coord_ant2 = temp2;
			
			incr1++;
			incr2++;
			
			//valla horizonta, cambio de coordenada inicial
			
			temp2 = new Coordenadas(coord_ant2.getX() - incr2,coord_ant2.getY());
			temp1 = new Coordenadas(coord_ant1.getX() - incr1, coord_ant1.getY());
			aristas.add(new Valla(temp1,coord_ant1,1));
			aristas.add(new Valla(temp2,coord_ant2,1));
			
			coord_ant1 = temp1;
			coord_ant2 = temp2;
			
			incr1++;
			incr2++;
			
			//valla vertical
			
			temp2 = new Coordenadas(coord_ant2.getX(), coord_ant2.getY() - incr2);
			temp1 = new Coordenadas(coord_ant1.getX(), coord_ant1.getY() - incr1);
			aristas.add(new Valla(temp1,coord_ant1,1));
			aristas.add(new Valla(temp2,coord_ant2,1));
			
			coord_ant1 = temp1;
			coord_ant2 = temp2;
			
			incr1++;
			incr2++;
			
		}
		
		temp = new Coordenadas(coord_ant2.getX(),coord_ant2.getY()-1);
		aristas.add(new Valla(temp,coord_ant2,1));
		aristas.add(new Valla(temp1,temp,1));
		return aristas;
	}
   
   @Test
   public void TestSinIntencion() 
   { 
      Superficie s;
      Coordenadas c1;
      Coordenadas c2;
      Coordenadas c3;
      Coordenadas c4;
      Coordenadas c5;
      Coordenadas c6;

      Valla v1;
      Valla v2;
      Valla v3;
      Valla v4;
      
      ArrayList<Valla> vs = new ArrayList<Valla>();

      long promedio;
      long lg = System.currentTimeMillis();
      int hasta = 851;
      int num1=0;
 
      for(int num = 1; num < hasta; num++)
      {
         
         // Primer zona resguardada de 1x1 
         if (num == 1)
         {
            c1 = new Coordenadas(1,1);
            c2 = new Coordenadas(1,2);
            c3 = new Coordenadas(2,1);
            c4 = new Coordenadas(2,2);
         
            v1 = new Valla(c1,c2,2);     
            v2 = new Valla(c1,c3,2);   
            v3 = new Valla(c2,c4,2);   
            v4 = new Valla(c3,c4,2);   
        
            vs.add( v1 );
            vs.add( v2 );
            vs.add( v3 );
            vs.add( v4 );    
         }
         
         if (num % 25 == 0)
         {
            
            c1 = new Coordenadas(num,num);
            c2 = new Coordenadas(num,num +1);
            c3 = new Coordenadas(num+1,num);
            c4 = new Coordenadas(num+1,num+1);
         
            v1 = new Valla(c1,c2,1);     
            v2 = new Valla(c1,c3,1);   
            v3 = new Valla(c2,c4,1);   
            v4 = new Valla(c3,c4,1);   
            
            vs.add( v1 );
            vs.add( v2 );
            vs.add( v3 );
            vs.add( v4 );
           
         }
         else
         {
         
            // Aumenta zona resguardada 
            if (num != 1 && num!= hasta -1)
            {
               c1 = new Coordenadas(num,1);
               c2 = new Coordenadas(num,2);
               c3 = new Coordenadas(num+1,1);
               c4 = new Coordenadas(num+1,2);
               c5 = new Coordenadas(num,num+1);
               c6 = new Coordenadas(num+1,num+1);
             
            
               v1 = new Valla(c5,c6,1);       
               v2 = new Valla(c1,c3,2);   
               v3 = new Valla(c2,c4,2);   
               v4 = new Valla(c3,c4,2);   
               
               vs.add( v1 );
               vs.add( v2 );
               vs.add( v3 );
               vs.add( v4 );    
            }
            
            if (num == hasta -1)
            {
               c1 = new Coordenadas(num,1);
               c2 = new Coordenadas(num,2);
               c3 = new Coordenadas(num+1,1);
               c4 = new Coordenadas(num+1,2);
               c5 = new Coordenadas(num,num+1);
               c6 = new Coordenadas(num+1,num+1);
            
               v1 = new Valla(c5,c6,2);       
               v2 = new Valla(c1,c3,2);   
               v3 = new Valla(c2,c4,2);   
               v4 = new Valla(c3,c4,2);   
               
               vs.add( v1 );
               vs.add( v2 );
               vs.add( v3 );
               vs.add( v4 ); 
            }
         }
         
         promedio = 0;
         
         for (int i = 0; i < 11; i++)
         {
            lg = System.currentTimeMillis();
            s = new Superficie(vs, 2); 
            s.calcularSuperficieResguardada();    
            promedio = promedio + System.currentTimeMillis()-lg;
         }
          
          // #vallas | tiempo promedio | superficie total
         //System.out.println(num*4 + " " + (promedio/10) + " " + res);
         
         if (num ==1 || num > num1 + 25 )
         {    
            System.out.println(num*4 + " " + (promedio/10));
            
            num1 = num;
         }
      }
   }


}
