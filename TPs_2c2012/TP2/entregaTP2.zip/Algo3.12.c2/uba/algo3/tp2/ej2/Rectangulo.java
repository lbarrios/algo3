package uba.algo3.tp2.ej2;

public class Rectangulo
{

	Valla base;
	Valla altura;
	
	public int calcularSuperficie()
	{
		return (base.getExtremo2().getX() - base.getExtremo1().getX()) * (altura.getExtremo2().getY() - altura.getExtremo1().getY());
	}

	public Rectangulo(Valla altura, Valla base)
	{
		super();
		this.base = base;
		this.altura = altura;
	}

	public boolean pertenece(Coordenadas coord)
	{
		int y = coord.getY();
		int x = coord.getX();
		
		return altura.getExtremo1().getY() <= y && y <= altura.getExtremo2().getY() && base.getExtremo1().getX() <= x && x <= base.getExtremo2().getX();
	}
	
	
}
