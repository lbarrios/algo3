package uba.algo3.tp2.ej2;

import java.util.ArrayList;

public class Vallas implements Comparable<Vallas>
{	
	ArrayList<Valla> vallas;
	Coordenadas c;
	
	public Coordenadas getCoordenadas()
	{
		return c;
	}
	
	public Vallas(Coordenadas c, Valla a)
	{
		super();
		this.c = c;
		this.vallas = new ArrayList<Valla>();
		vallas.add(a);
	}
	
	public Vallas(ArrayList<Valla> vallas)
	{
		super();
		this.vallas = vallas;
	}
	
	public void agregarValla(Valla a)
	{
		vallas.add(a);
	}
	
	public void eliminarValla(Valla a)
	{
		int i;
		for(i = 0; i < vallas.size(); i++)
		{
			if(vallas.get(i).equals(a))
			{
				vallas.remove(i);
				break;
			}
		}
	}
	
	public ArrayList<Valla> getVallas()
	{
		return vallas;
	}
	
	public int cantidad()
	{
		return vallas.size();
	}

	public int compareTo(Vallas arg0)
	{
		return this.cantidad() - arg0.cantidad();
	}

	public Valla irSur(Coordenadas c)
	{
		for(Valla v : vallas)
		{
			Coordenadas c2 = v.obtenerExtremo(c);
			if(c2.getY() < c.getY())
			{
				return v;
			}
		}
		return null;
	}

	public Valla irEste(Coordenadas c)
	{
		for(Valla v : vallas)
		{
			Coordenadas c2 = v.obtenerExtremo(c);
			if(c2.getX() > c.getX())
			{
				return v;
			}
		}
		return null;
	}

	public Valla irNorte(Coordenadas c)
	{
		for(Valla v : vallas)
		{
			Coordenadas c2 = v.obtenerExtremo(c);
			if(c2.getY() > c.getY())
			{
				return v;
			}
		}
		return null;
	}

	public Valla irOeste(Coordenadas c)
	{
		for(Valla v : vallas)
		{
			Coordenadas c2 = v.obtenerExtremo(c);
			if(c2.getX() < c.getX())
			{
				return v;
			}
		}
		return null;
	}
	

	public String toString()
	{
		return "[" + (vallas != null ? vallas : "") + "]\n";
	}
}