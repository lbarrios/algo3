package uba.algo3.tp2.ej1;



public class Camino {



//	private int idAdyacente;

	private Ciudad adyacente;

	private int pesoTolerado;

	

	

	public Camino(Ciudad adyacente, int peso) {

	 this.adyacente= adyacente;

	 this.pesoTolerado= peso;

	}

	

//	public int obtenerIdAdyacente(){

//		return idAdyacente;

//	}

	

	public int getPesoTolerado(){

		return pesoTolerado;

	}

	public Ciudad getCiudad(){

		return adyacente;

	}

	

	@Override

	public String toString()

	{

		return "Ciudad Adyacente: " + adyacente + " pesoTolerado: " + pesoTolerado; //+ " Fue Visto?: " + yaVisto;

	}

}
