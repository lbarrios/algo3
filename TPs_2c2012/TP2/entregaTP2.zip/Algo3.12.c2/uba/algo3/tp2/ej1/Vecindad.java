package uba.algo3.tp2.ej1;



public class Vecindad {



   String ciudad1;

   String ciudad2;

   int peso_maximo;

	   

   public Vecindad(String primero, String segundo, int peso){

      this.ciudad1 = primero;

      this.ciudad2 = segundo;

      peso_maximo= peso;

   }

   

   public String getCiudad1()

   {

      return ciudad1;

   }

  

   public String getCiudad2()

   {

      return ciudad2;

   }

   

   public int pesoEntreCiudades()

   {

	   return peso_maximo;

   }

	

}