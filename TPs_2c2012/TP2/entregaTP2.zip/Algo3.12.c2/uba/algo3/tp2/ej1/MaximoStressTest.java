package uba.algo3.tp2.ej1;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import org.junit.Test;



public class MaximoStressTest {

	

	static private ArrayList<String> aristas;



    FileWriter fstream;

	BufferedWriter out = null;



	

	@Test

	   public void TestPeorCasoCompleto() 

	   {

		    leer("peor_caso_completo");

		

	        int pesoMaximo;

	        long lg;

	        int r;

	        long promedio = 0; 

	        int cant_nodos;

	        int repeticiones=10;

	        int cant_nodos_mas_uno=0;

	      

	      

			for(cant_nodos = 100; cant_nodos <= 2000; cant_nodos+=100)

			{			

			  aristas = new ArrayList<String>();

				

		      for(int num = 1; num <= cant_nodos; num++)

		      {

			       for(int j= num+1; j <=cant_nodos; j++ ) 

			       {

			        	 aristas.add( "ciudad" +  num );

			        	 aristas.add( "ciudad" + j);

			        	 aristas.add( "" + j);

			        }

			        

			         

		        }

			    cant_nodos_mas_uno= cant_nodos +1;

			    aristas.add( "ciudad" + cant_nodos );

		  	    aristas.add( "ciudad" + cant_nodos_mas_uno);

		  	    aristas.add( "" + 1);

			      

		        

		  	    promedio = 0;

	  	  

		        for (int i = 0; i < repeticiones; i++)

		        {

		        	Maximo e = new Maximo();

		        	lg = System.currentTimeMillis(); 

		        	 

		        	pesoMaximo = e.obtenerMaximo( "ciudad1","ciudad" + cant_nodos_mas_uno, aristas );

	 

		            long tiempoLuegoDeLaCorrida = System.currentTimeMillis();

		            

		            long resta = tiempoLuegoDeLaCorrida-lg;

		            

		            promedio = promedio + resta;

		            			

					System.out.println( "Iteracion " + i + " System.currentTimeMillis(): " + resta );

					System.out.println( "\n");

		            

		         }

		         System.out.println( "***************************************************************************");

		         System.out.println( "promedio TestPeorCaso con " + repeticiones + " repeticiones: " + promedio/repeticiones );

		         System.out.println( "***************************************************************************");

		         

		         escribir(cant_nodos_mas_uno,promedio,repeticiones);

		      }

			

			  cerrar();

	

	    }

	

	

	   @Test

	   public void TestMejorCasoCompleto() // origen con solo un vecino (destino) 

	   {



		  leer("mejor_caso_origen_con_solo_un_vecino_destino");

		   

	      int pesoMaximo;

	      long lg;

	      long promedio = 0; 

	      aristas = new ArrayList<String>();

	      int cant_nodos;

	      

     	  for(cant_nodos = 100; cant_nodos <= 800; cant_nodos+=50) {

     		  

     		  aristas = new ArrayList<String>();

    	      aristas.add( "ciudad1");

         	  aristas.add( "ciudad2");

         	  aristas.add( "" + 2000);



     	  	  promedio = 0; 



		      for(int num = 2; num <= cant_nodos; num++)

		      { 	

		    		    	  

			         for(int j= num+1; j <=cant_nodos; j++ ) {

			       	 

	

			        	 aristas.add( "ciudad" +  num );

			        	 aristas.add( "ciudad" + j);

			        	 aristas.add( "" + j);

			         }

			         

		      }

		        

		      int repeticiones=10;

		      

		         for (int i = 0; i < repeticiones; i++)

		         {

		        	Maximo e = new Maximo();

		        	lg = System.currentTimeMillis(); 

		        	 

		        	pesoMaximo = e.obtenerMaximo( "ciudad1","ciudad2", aristas );

		            

		             

		            long tiempoLuegoDeLaCorrida = System.currentTimeMillis();

		            

		            long resta = tiempoLuegoDeLaCorrida-lg;

		            

		            promedio = promedio + resta;

		            

		            

					pesoMaximo++;

					System.out.println( "Iteracion " + i + " System.currentTimeMillis(): " + resta );

					System.out.println( "\n");

		            

		         }

		         System.out.println( "***************************************************************************");

		         System.out.println( "promedio TestMejorCaso con " + repeticiones + " repeticiones: " + promedio/repeticiones );

		         System.out.println( "***************************************************************************");

		      

		         escribir(cant_nodos,promedio,repeticiones);

     	  

     	  }

     	  

     	  cerrar();

	

	}    

	  

	   @Test

	   public void TestPeorCasoNoCompleto() 

	   {

		   

		  leer("peor_caso_no_completo"); 

		   

	      int pesoMaximo;

	      long lg;

	      int r;

	      long promedio = 0; 

	      int cant_nodos;

	      int repeticiones=10;

	      int cant_nodos_menos_uno=0;



		for(cant_nodos = 100; cant_nodos <= 2000; cant_nodos+=50)

		{

		  aristas = new ArrayList<String>();

			

	      for(int num = 1; num <= cant_nodos; num++)

	      { 	 

	    	 for(int j= num+1; j <=num+15; j++ )

	    	 {

	        	 aristas.add( "ciudad" +  num );

	        	 aristas.add( "ciudad" + j);

	        	 aristas.add( "" + j);



		      }

		  	         

	       }

	      cant_nodos_menos_uno= cant_nodos - 1;

 

     	  promedio = 0;

     	  

         for (int i = 0; i < repeticiones; i++)

         {

        	 Maximo e = new Maximo();

        	lg = System.currentTimeMillis(); 

        	 

        	pesoMaximo = e.obtenerMaximo( "ciudad1","ciudad2", aristas );

     

            long tiempoLuegoDeLaCorrida = System.currentTimeMillis();

            

            long resta = tiempoLuegoDeLaCorrida-lg;

            

            promedio = promedio + resta;

  

			System.out.println( "Iteracion " + i + " System.currentTimeMillis(): " + resta );

			System.out.println( "\n");

            

         }

         System.out.println( "***************************************************************************");

         System.out.println( "promedio TestPeorCasoNoCompleto con " + repeticiones + " repeticiones: " + promedio/repeticiones );

         System.out.println( "***************************************************************************");



         escribir(cant_nodos,promedio,repeticiones);



	      }

		

	     cerrar();

		

	

	}

	   

	   

	   

	   



	   @Test

	   public void TestMejorCasoNoCompleto() //exactamente N-1 aristas

	   {

		   

		  leer("mejor_caso_no_completo"); 

		   

	      int pesoMaximo;

	      long lg;

	      int r;

	      long promedio = 0; 

	      int cant_nodos;

	      int repeticiones=10;



		  for(cant_nodos = 100; cant_nodos <= 50000; cant_nodos+=100)

		  {

			

			  aristas = new ArrayList<String>();

			

		      for(int num = 1; num < cant_nodos; num++)

		      { 	 

	            aristas.add( "ciudad" +  num );

		        aristas.add( "ciudad" + (num+1));

		        aristas.add( "" + num);

		      

		      }

	   

     	      promedio = 0;

     	  

		         for (int i = 0; i < repeticiones; i++)

		         {

		        	 Maximo e = new Maximo();

		        	lg = System.currentTimeMillis(); 

		        	 

		        	pesoMaximo = e.obtenerMaximo( "ciudad1","ciudad2", aristas );

		     

		            long tiempoLuegoDeLaCorrida = System.currentTimeMillis();

		            

		            long resta = tiempoLuegoDeLaCorrida-lg;

		            

		            promedio = promedio + resta;

		  

					System.out.println( "Iteracion " + i + " System.currentTimeMillis(): " + resta );

					System.out.println( "\n");

		            

		         }

		         System.out.println( "***************************************************************************");

		         System.out.println( "promedio TestPeorCasoNoCompleto con " + repeticiones + " repeticiones: " + promedio/repeticiones );

		         System.out.println( "***************************************************************************");

	

		         escribir(cant_nodos,promedio,repeticiones);



	      }

		

	      cerrar();

	

	}

	   

  /**

	   

	   @Test

	   public void TestCasoAzarNoCompleto() 

	   {

		  leer("TestCasoAzarNoCompleto"); 

		  	   

	      int pesoMaximo;

	      long lg;

	      int r;

	      long promedio = 0; 

	      int cant_nodos;

	      int repeticiones=10;

	      int cant_nodos_menos_uno=0;

	      

	        	      

		  for(cant_nodos = 100; cant_nodos <= 2000; cant_nodos+=100)

		  {

			

			  aristas = new ArrayList<String>();

			

		      for(int num = 1; num <= cant_nodos; num++)

		      { 	 

		    	     for(int j= num+1; j <=num+15; j++ ) {

	

		    	    	 aristas.add( "ciudad" +  num );

			        	 aristas.add( "ciudad" + j);

			        	 aristas.add( "" + j);

			        	 

			        //	con peso de la arista aleatorio.

	//		        	 r = new Double(Math.random() * 100).intValue();

	//		        	 r++;

	//		        	 aristas.add( "" + r);

	//	        

			         }

			    	         

		       }

	             promedio = 0;

	     	  

		         for (int i = 0; i < repeticiones; i++)

		         {

		        	 int x = new Double(Math.random() * cant_nodos).intValue();

	                 int y = new Double(Math.random() * cant_nodos).intValue();

	  	 

		        	 

		        	Maximo e = new Maximo();

		        	lg = System.currentTimeMillis(); 

		        	 

		        	pesoMaximo = e.obtenerMaximo( "ciudad" +  String.valueOf( x ),"ciudad" + String.valueOf( y ), aristas );

	        	

		            long tiempoLuegoDeLaCorrida = System.currentTimeMillis();

		            

		            long resta = tiempoLuegoDeLaCorrida-lg;

		            

		            promedio = promedio + resta;

		           				

					System.out.println( "Iteracion " + i + " System.currentTimeMillis(): " + resta );

					System.out.println( "\n");

		            

		         }

		         System.out.println( "***************************************************************************");

		         System.out.println( "promedio TestCasoAzarNoCompleto con " + repeticiones + " repeticiones: " + promedio/repeticiones );

		         System.out.println( "***************************************************************************");

		         

		         escribir(cant_nodos,promedio,repeticiones);

		         	         

	       }

		

		   cerrar();

		}

	  	   

	   @Test

	   public void TestCasoAzarCompleto() 

	   {

		  leer("TestCasoAzarCompleto"); 

		   

	      int pesoMaximo;

	      long lg;

	      int r;

	      long promedio = 0; 

	      int cant_nodos;

	      int repeticiones=10;

	      

	      

		for(cant_nodos = 100; cant_nodos <= 1400; cant_nodos+=100) {

			

		  aristas = new ArrayList<String>();

			

	      for(int num = 1; num <= cant_nodos; num++)

	      { 	 

	    	     for(int j= num+1; j <=cant_nodos; j++ ) {



	    	    	 aristas.add( "ciudad" +  num );

		        	 aristas.add( "ciudad" + j);

		        	 aristas.add( "" + j);

		        	 

		        //	con peso de la arista aleatorio 

//		        	 r = new Double(Math.random() * 100).intValue();

//		        	 r++;

//		        	 aristas.add( "" + r);

	              }

		   }

	             

     	     promedio = 0;

     	  

	         for (int i = 0; i < repeticiones; i++)

	         {

	        	 int x = new Double(Math.random() * cant_nodos).intValue();

                 int y = new Double(Math.random() * cant_nodos).intValue();

  	 

	        	 

	        	Maximo e = new Maximo();

	        	lg = System.currentTimeMillis(); 

	        	 

	        	pesoMaximo = e.obtenerMaximo( "ciudad" +  String.valueOf( x ),"ciudad" + String.valueOf( y ), aristas );

	       		        	

	            long tiempoLuegoDeLaCorrida = System.currentTimeMillis();

	            

	            long resta = tiempoLuegoDeLaCorrida-lg;

	            

	            promedio = promedio + resta;

	            				

				System.out.println( "Iteracion " + i + " System.currentTimeMillis(): " + resta );

				System.out.println( "\n");

	            

	         }

	         System.out.println( "***************************************************************************");

	         System.out.println( "promedio TestCasoAzarCompleto con " + repeticiones + " repeticiones: " + promedio/repeticiones );

	         System.out.println( "***************************************************************************");

	         

	         

	         escribir(cant_nodos,promedio,repeticiones);

	         	                  

	      }

		

		  cerrar();

	

	}

	   

	*/   	   

	   

	   // --------------------------- METODOS DE LECTURA/ESCRITURA ----------------------

	   

	   private void leer(String txt){

		   

			try

			{

				fstream = new FileWriter(txt + ".txt");

				out = new BufferedWriter(fstream);

			} catch (IOException ex)

			{

				ex.printStackTrace();

			}

		   

	   }

	   

       private void escribir(int cantNodos, long prom, int rep){

    	   try

   		{

   			out.write(cantNodos + " " + prom/rep + '\n');

   		} catch (IOException ex)

   		{

   			ex.printStackTrace();

   		}

   	      

       }

    

	   private void cerrar(){

		   try{

			   out.close();

			} catch (IOException ex){

				ex.printStackTrace();

			}

		}

	   



	   

}