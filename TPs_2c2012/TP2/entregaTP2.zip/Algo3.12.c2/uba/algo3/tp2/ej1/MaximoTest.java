package uba.algo3.tp2.ej1;



import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.StringTokenizer;
import org.junit.Test;



public class MaximoTest {



	ArrayList<String> vecindades;

	Maximo e = new Maximo();

	

	@Test

	public void testObtenerMaximo()

	{		

		

		representData("Richmond Sidney 3; Richmond Penrith 2; Sidney Penrith 1;");

		e = new Maximo();

		int pesoMaximo = e.obtenerMaximo("Penrith", "Sidney", vecindades); 

		assertEquals(2,pesoMaximo);

		

		representData("Kingaroy Caboolture 4; Caboolture Brisbane 3; Kingaroy Dalby 3; Dalby Brisbane 5;");

		e = new Maximo();

		pesoMaximo = e.obtenerMaximo("Kingaroy", "Brisbane", vecindades); 

		assertEquals(3,pesoMaximo);

		

		representData("Hamilton Ballarat 4; Hamilton Warmambool 7; Frankston Geelong 6; Ballarat Melbourne 5; Ballarat Geelong 5; Melbourne Frankston 7;");

		e = new Maximo();

		pesoMaximo = e.obtenerMaximo("Hamilton", "Melbourne", vecindades); 

		assertEquals(4,pesoMaximo);

		

		representData("Geelong Penrith 1; Sidney Penrith 2; Sidney Dalby 2; Dalby Penrith 2; Dalby Geelong 1;");

		e = new Maximo();

		 pesoMaximo = e.obtenerMaximo("Sidney", "Geelong", vecindades); 

		assertEquals(1,pesoMaximo);

		

		representData("Sidney Geelong 3; Sidney Melbourne 2; Sidney Ballarat 3; Ballarat Penrith 2; Geelong Penrith 1; Geelong Melbourne 3; Geelong Ballarat 4; Melbourne Penrith 3;");

		e = new Maximo();

		pesoMaximo = e.obtenerMaximo("Sidney", "Penrith", vecindades); 

		assertEquals(3,pesoMaximo);

		

		representData("Zaraza Penrith 2; Zaraza Sidney 18; Sidney Geelong 3; Sidney Melbourne 2; Sidney Ballarat 3; Ballarat Penrith 2; Geelong Penrith 1; Geelong Melbourne 3; Geelong Ballarat 4; Melbourne Penrith 3;");

		e = new Maximo();

		pesoMaximo = e.obtenerMaximo("Sidney", "Zaraza", vecindades); 

		assertEquals(18,pesoMaximo);

		

		representData("A F 2; A D 4; A B 4; B F 3; B D 1; B C 3; B E 5; C D 5; C E 10; C G 2; E G 8; E H 7; G H 3;");

	    e = new Maximo();

	    pesoMaximo = e.obtenerMaximo("A", "G", vecindades);

	    assertEquals(4,pesoMaximo);

	      

	    representData("A D 5; A B 7; B D 9; B E 7; B C 8; C E 5; D E 15; D F 6; E F 8; E G 9; F G 11;");

	    e = new Maximo();

	    pesoMaximo = e.obtenerMaximo("B", "F", vecindades);

	    assertEquals(9,pesoMaximo);   

	      

	    representData("A B 20; A C 13; B D 14; C D 15; C E 14; D F 50; E F 50; F G 15; A G 16; D G 17; A D 21;");

	    e = new Maximo();

	    pesoMaximo = e.obtenerMaximo("F", "G", vecindades); 

	    assertEquals(17,pesoMaximo);

	      

	    representData("A B 18; A C 19; B C 20; C D 16;");

	    e = new Maximo();

	    pesoMaximo = e.obtenerMaximo("A", "D", vecindades); 

	    assertEquals(16,pesoMaximo);

		

	    representData("A B 11; B C 9; C D 9; D G 10; A J 8; J I 7; D E 8; E F 7; F I 2; G H 10; H I 6; B I 5; C E 4;");

	    e = new Maximo();

	    pesoMaximo = e.obtenerMaximo("A", "I", vecindades); 

	    assertEquals(7,pesoMaximo);

	      

	    representData("A B 5; B C 2; C D 1; D E 8; E F 4; F G 10;"); // �---�---�---�---�---�---�

	    e = new Maximo();

	    pesoMaximo = e.obtenerMaximo("C", "F", vecindades); 

	    assertEquals(1,pesoMaximo);

	      

	    representData("A B 7; B C 4; C D 10; D E 15; E A 9; A F 8; B F 8; C F 7; D F 2; E F 8;"); 

	    e = new Maximo();

	    pesoMaximo = e.obtenerMaximo("F", "C", vecindades); 

	    assertEquals(8,pesoMaximo);

	      

	    representData("A B 7; B C 4; C D 10; D E 15; E A 9; A F 8; B F 8; C F 7; D F 2; E F 8; G H 7; H I 4; I J 10; J K 15; K G 9; G L 8; H L 8; I L 7; J L 2; K L 8; E G 8; D H 9;");      

	    e = new Maximo();

	    pesoMaximo = e.obtenerMaximo("B", "J", vecindades); 

	    assertEquals(8,pesoMaximo);

	      

	    representData("Geelong Penrith 10; Sidney Penrith 10; Sidney Dalby 10; Dalby Penrith 10; Geelong Sidney 10; Geelong Brisbane 10;");      

	    e = new Maximo();

	    pesoMaximo = e.obtenerMaximo("Geelong", "Dalby", vecindades); 

	    assertEquals(10,pesoMaximo);

	      	

}

	

	private void representData(String string)

	{

		 vecindades = new ArrayList<String>();

		

		StringTokenizer st = new StringTokenizer(string, ";");



		while(st.hasMoreTokens())

		{

			StringTokenizer s = new StringTokenizer(st.nextToken()," ");

			vecindades.add(s.nextToken());

			vecindades.add(s.nextToken());

			vecindades.add(s.nextToken());

		}

		

		

	}

	

}

