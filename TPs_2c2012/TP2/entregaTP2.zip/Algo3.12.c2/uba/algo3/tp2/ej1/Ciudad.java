package uba.algo3.tp2.ej1;



import java.util.ArrayList;



public class Ciudad implements Comparable<Ciudad>  {



//	private int id;

	private String nombre;

	private ArrayList<Camino> vecinos;

	private int pesoHastaAqui=0;

	private boolean yaVista= false;



//	Ciudad(int id, String nombre, ArrayList<Camino> ady){

////		this.id= id;

//		this.nombre= nombre;

//		adyacentes= ady;

//	}

	

	Ciudad(String nombre){

		this.nombre= nombre;

		vecinos= new ArrayList<Camino>();

	}

	

//	public int obtenerId(){

//		return id;

//	}

	

	public String getNombre(){

		return nombre;

	}

	

	public ArrayList<Camino> getVecinos(){

		return vecinos;

	}

				

//	public void agregarAdy(ArrayList<Camino> ady){

//		adyacentes= ady;

//	}

	

	

	public int getPeso()

	{

		return pesoHastaAqui;

	}

	

	public void setPeso(int peso)

	{

		pesoHastaAqui= peso;

	}

	@Override

	public String toString()

	{

		return nombre + " pesoHastaAqui: " + pesoHastaAqui; //+ " Fue Visto?: " + yaVisto;

	}

	

//	public boolean equals(Ciudad otra)

//	{

//		return this.getNombre().equals(otra);

//	}

	

	public boolean estaConfirmada()

	{

		return yaVista;

	}

	

	public void confirmar()

	{

		yaVista= true;

	}

	

	public int compareTo(Ciudad otra){ //implementa el metodo compareTo de la interfaz Comparable

		if(this.pesoHastaAqui == otra.pesoHastaAqui)

			return 0;

		else

			if(this.pesoHastaAqui > otra.pesoHastaAqui)

				return -1; //como PriorityQueue es un MinHeap, el elem "mas chico" es el de mayor pesoHastaAqui

			else

				return 1;

	}

	

	@Override

	public int hashCode() {

		final int prime = 31;

		int result = 1;

		result = prime * result

				+ ((vecinos == null) ? 0 : vecinos.hashCode());

		result *= prime * result + ((nombre == null) ? 0 : nombre.hashCode());

		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());

		return result;

	}



	@Override

	public boolean equals(Object obj) {

		if (this == obj)

			return true;

		if (obj == null)

			return false;

		if (getClass() != obj.getClass())

			return false;

		Ciudad other = (Ciudad) obj;

		if (vecinos == null) {

			if (other.vecinos != null)

				return false;

		} else if (!vecinos.equals(other.vecinos))

			return false;

		if (nombre == null) {

			if (other.nombre != null)

				return false;

		} else if (!nombre.equals(other.nombre))

			return false;

		if (pesoHastaAqui != other.pesoHastaAqui)

			return false;

		if (yaVista != other.yaVista)

			return false;

		return true;

	}

	

}