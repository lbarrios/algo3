package uba.algo3.tp2.ej1;

import java.util.ArrayList;
import java.util.HashMap;



public class Maximo {

			

			private HashMap<String, Ciudad> ciudades= new HashMap<String, Ciudad>();

									

			//obtenerMaximo es O(M)+O(MlogN) = O(MlogN), con M=cant tramos y N=cant ciudades

			public int obtenerMaximo(String ciudadOrigen, String ciudadDestino, ArrayList<String> caminos) {

			

			//Armado inicial de la estructura que contiene a las ciudades

			generarCiudades(ParseAVecinos(caminos)); //O(M)+O(M) = O(M)

	

			Ciudad origen = ciudades.get(ciudadOrigen); //O(1)

			//Me aseguro que voy a empezar por el origen, y al ponerle peso maximo,

			//podr� llegar con el peso tolerado a cada vecino.

			origen.setPeso(Integer.MAX_VALUE); //O(1)

			

			Ciudad destino = ciudades.get(ciudadDestino); //O(1)

									

			PriorityQueueExt<Ciudad> frontera = new PriorityQueueExt<Ciudad>(); //O(1)

			frontera.encolar(origen); //O(1), ya que es encolar un elemento en una cola vacia 

			

			//Mientras que tenga ciudades en la cola, sigo adelante

			//A menos que la pr�xima que elija sea el destino, en cuyo caso termino el algoritmo

			while ( !frontera.isEmpty() ) { //O(NlogN) + O(MlogN) = O(MlogN) + O(MlogN) = O(MlogN)

				Ciudad prox = frontera.getMax(); //O(logN)

				prox.confirmar(); //O(1)

				if(prox.equals(destino)){ //O(1)

					break;

				}//Recorro todos los vecinos de la ciudad que estoy mirando

				for ( Camino vecino: prox.getVecinos() ) { //O(grado(vecino))

					if(!vecino.getCiudad().estaConfirmada()) {

						

						int pesoAnteriorVecino = vecino.getCiudad().getPeso();

						

						//Me fijo cuanto podr�a pasar.

					    int minimo = Math.min(prox.getPeso(), vecino.getPesoTolerado());

					    

					    //Si puedo mejorar el peso hasta el vecino, le cambio el valor del peso.

					    if(pesoAnteriorVecino < minimo){

					    	vecino.getCiudad().setPeso(minimo);

					    	

					    	//Si el vecino no estaba en el heap, lo agrego

					   		if(pesoAnteriorVecino == 0)

					   	    	frontera.encolar( vecino.getCiudad() ); //O(logN)

					   	    else{//Las dos lineas siguientes las usabamos en la versi�n anterior.

					   	    	//frontera.remove(vecino.getCiudad());

					   	    	//frontera.add(vecino.getCiudad()); 

					   	    	

					   	        //Si ya estaba, entonces lo tenemos que reubicar en el lugar

					   	    	//que le corresponde en el heap.

					   	    	frontera.reubicar(vecino.getCiudad()); //O(logN)

					   	    }

					    }

					}

				}

			}

			//Devuelvo el valor buscado.

		    return destino.getPeso();

		}

	

	

	 public void generarCiudades(ArrayList<Vecindad> vecindades) { //O(M)

		   

	      for( Vecindad vecindad: vecindades )  //M veces

	      {	    	  

	         Ciudad ciudad1 = damevecino(ciudades, vecindad.getCiudad1() ); //O(1)

	         Ciudad ciudad2 = damevecino(ciudades, vecindad.getCiudad2() ); //O(1)

	         

	         ciudad1.getVecinos().add(new Camino(ciudad2,vecindad.pesoEntreCiudades())); //O(1)

	         ciudad2.getVecinos().add(new Camino(ciudad1,vecindad.pesoEntreCiudades())); //O(1)

	      }  

	 }

	

	 public Ciudad damevecino(HashMap<String, Ciudad> ciudades, String vecino)  //O(1)

	 { 		 

	      if (!ciudades.containsKey( vecino)) { 

	    	  Ciudad nuevaCiudad = new Ciudad(vecino);

	    	  ciudades.put(vecino, nuevaCiudad);

	      }

	      return (ciudades.get(vecino));

	 }

	    

	public static ArrayList<Vecindad> ParseAVecinos(ArrayList<String> vecindades) //O(M)

	{ 		

		   ArrayList<Vecindad> res = new ArrayList<Vecindad>();

		   for(int i=0; i<vecindades.size(); i+=3)

		   {

		      String vecino1 = vecindades.get(i);

		      String vecino2 = vecindades.get(i+1);

		      int peso_entre_ellos = Integer.parseInt(vecindades.get(i+2));

		      res.add(new Vecindad(vecino1, vecino2, peso_entre_ellos));

		   }

		   return res;

	}



}



