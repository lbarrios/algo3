package uba.algo3
;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import uba.algo3.ejemplotp.LinearPlateaoFilesTest;
import uba.algo3.ejemplotp.LinearPlateaoTest;
import uba.algo3.ejemplotp.TokenTest;
import uba.algo3.ejemplotp.UnoSoloCatedraTest;
import uba.algo3.ejemplotp.UnoSoloTest;
import uba.algo3.practica.McdTest;

@SuiteClasses(value={
                     McdTest.class,
                     LinearPlateaoTest.class,
                     LinearPlateaoFilesTest.class,
                     TokenTest.class,
                     UnoSoloTest.class,
                     UnoSoloCatedraTest.class
                     })
@RunWith(Suite.class)
public class SuitePractica {

}
