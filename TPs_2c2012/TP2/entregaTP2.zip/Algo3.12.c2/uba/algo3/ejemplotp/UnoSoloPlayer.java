package uba.algo3.ejemplotp;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import org.junit.Assert;



public class UnoSoloPlayer {

   int filas;
   int columnas;
   
   public void check( int fila, int columna, List tokens, List testPath ) {
      filas = fila;
      columnas = columna;
      run( testPath, new Vector( tokens ) );
   }
   

   public void run( List<Token> path, List<Token> tokens ) {
      Iterator<Token> stream = new Vector( path ).iterator();
      
      while( stream.hasNext() ) {
         Token origin = stream.next();
         Token dest = stream.next();

         Assert.assertTrue( origin.within( filas, columnas ) ); 
         Assert.assertTrue( dest.within( filas, columnas ) );
         Assert.assertTrue( tokens.contains( origin ) );
         Assert.assertTrue( tokens.contains( origin.between( dest ) ) );
         Assert.assertFalse( tokens.contains( dest ) );
         
         tokens.remove( origin );
         tokens.remove( origin.between( dest ) );
         tokens.add( dest );
         
      } 
      Assert.assertEquals( 1, tokens.size() );

   }

   
}
